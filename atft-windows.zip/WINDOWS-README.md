# ATFT solution and factory source

This archive contains the current generated ATFT application and the .NET
factory that builds it. ATFT itself is React/TypeScript, not a .NET application.
Extract the ZIP and open PowerShell in the extracted root folder.

## Run the generated ATFT application

Install Node.js 22 or later, then run:

```powershell
cd atft
npm ci
npm run dev -- --host 127.0.0.1
```

Open the localhost URL printed by Vite. To build and preview production output:

```powershell
npm run build
npm run preview -- --host 127.0.0.1
```

## Build and check the .NET factory

Install the .NET 8 SDK and Git. From the extracted root:

```powershell
dotnet restore .\factory\src\Factory.csproj
dotnet build .\factory\src\Factory.csproj -c Release
$env:FACTORY_CONFIG_DIR = (Resolve-Path .\factory).Path
dotnet run --project .\factory\src\Factory.csproj -c Release -- --help
dotnet run --project .\factory\src\Factory.csproj -c Release -- --check-line --target atft --line careful
```

No Visual Studio .sln file is required; Factory.csproj is the entry project.
The Bash launcher bin/factory is not needed for these commands.

## Generate additional work

Generation also requires an installed, authenticated pi agent. The factory
launches its harness directly with UseShellExecute=false. A Windows npm pi.cmd
shim alone may not be launchable this way; use WSL for generation unless you
have configured a directly executable Windows harness. Native Windows agent
execution has not been tested. Building and checking a line do not invoke pi.

Once the harness is available, from the extracted root with FACTORY_CONFIG_DIR
set as above:

```powershell
dotnet run --project .\factory\src\Factory.csproj -c Release -- --run atft-windows --target atft --line careful --seed atft/docs/iterations/001-.md
```

Generation creates commits. Configure your Git user.name and user.email first.
The seed above describes the existing iteration; use a new spec for new work.
Saved Linux run settings and plans are deliberately excluded so their absolute
paths and completion state do not get reused on Windows. New run state is stored
under factory/runs/. The legacy atft/.factory plan is also excluded.

Dependencies, Git history, build caches, and test reports are not included.
This is a source snapshot, not a Windows-tested installer.
